package dardo.bb.go;

public class Item {

	protected String name;
	protected String description;
	
}
