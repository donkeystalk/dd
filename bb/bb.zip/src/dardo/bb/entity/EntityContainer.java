package dardo.bb.entity;

public class EntityContainer {

	public static Player player;
	
}
